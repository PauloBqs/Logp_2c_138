﻿namespace AppSimProva_Michelle
{
    partial class FrmGames
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblJogo1 = new System.Windows.Forms.Label();
            this.lblJogo2 = new System.Windows.Forms.Label();
            this.lblJogo3 = new System.Windows.Forms.Label();
            this.txtJogo1 = new System.Windows.Forms.TextBox();
            this.txtJogo2 = new System.Windows.Forms.TextBox();
            this.txtJogo3 = new System.Windows.Forms.TextBox();
            this.lblVlrJg1 = new System.Windows.Forms.Label();
            this.lblVlrJogo2 = new System.Windows.Forms.Label();
            this.lblVlrJogo3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl1parc = new System.Windows.Forms.Label();
            this.lbl2parc = new System.Windows.Forms.Label();
            this.lbl3parc = new System.Windows.Forms.Label();
            this.lbl4parc = new System.Windows.Forms.Label();
            this.lblVlr1parc = new System.Windows.Forms.Label();
            this.lblVlr2parc = new System.Windows.Forms.Label();
            this.lblVlr3parc = new System.Windows.Forms.Label();
            this.lblVlr4parc = new System.Windows.Forms.Label();
            this.btnCalc = new System.Windows.Forms.Button();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.lblTitulo);
            this.panel3.Location = new System.Drawing.Point(2, 1);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(757, 99);
            this.panel3.TabIndex = 1;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.BackColor = System.Drawing.Color.Transparent;
            this.lblTitulo.Font = new System.Drawing.Font("Showcard Gothic", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblTitulo.Location = new System.Drawing.Point(203, 17);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(375, 60);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "LOJA DE JOGOS";
            // 
            // lblJogo1
            // 
            this.lblJogo1.AutoSize = true;
            this.lblJogo1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJogo1.ForeColor = System.Drawing.Color.White;
            this.lblJogo1.Location = new System.Drawing.Point(12, 157);
            this.lblJogo1.Name = "lblJogo1";
            this.lblJogo1.Size = new System.Drawing.Size(57, 20);
            this.lblJogo1.TabIndex = 2;
            this.lblJogo1.Text = "Jogo 1";
            // 
            // lblJogo2
            // 
            this.lblJogo2.AutoSize = true;
            this.lblJogo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJogo2.ForeColor = System.Drawing.Color.White;
            this.lblJogo2.Location = new System.Drawing.Point(12, 228);
            this.lblJogo2.Name = "lblJogo2";
            this.lblJogo2.Size = new System.Drawing.Size(57, 20);
            this.lblJogo2.TabIndex = 3;
            this.lblJogo2.Text = "Jogo 2";
            // 
            // lblJogo3
            // 
            this.lblJogo3.AutoSize = true;
            this.lblJogo3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJogo3.ForeColor = System.Drawing.Color.White;
            this.lblJogo3.Location = new System.Drawing.Point(12, 305);
            this.lblJogo3.Name = "lblJogo3";
            this.lblJogo3.Size = new System.Drawing.Size(57, 20);
            this.lblJogo3.TabIndex = 4;
            this.lblJogo3.Text = "Jogo 3";
            // 
            // txtJogo1
            // 
            this.txtJogo1.Location = new System.Drawing.Point(92, 157);
            this.txtJogo1.Name = "txtJogo1";
            this.txtJogo1.Size = new System.Drawing.Size(130, 20);
            this.txtJogo1.TabIndex = 5;
            // 
            // txtJogo2
            // 
            this.txtJogo2.Location = new System.Drawing.Point(92, 230);
            this.txtJogo2.Name = "txtJogo2";
            this.txtJogo2.Size = new System.Drawing.Size(130, 20);
            this.txtJogo2.TabIndex = 6;
            // 
            // txtJogo3
            // 
            this.txtJogo3.Location = new System.Drawing.Point(92, 305);
            this.txtJogo3.Name = "txtJogo3";
            this.txtJogo3.Size = new System.Drawing.Size(130, 20);
            this.txtJogo3.TabIndex = 7;
            // 
            // lblVlrJg1
            // 
            this.lblVlrJg1.AutoSize = true;
            this.lblVlrJg1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVlrJg1.ForeColor = System.Drawing.Color.White;
            this.lblVlrJg1.Location = new System.Drawing.Point(261, 159);
            this.lblVlrJg1.Name = "lblVlrJg1";
            this.lblVlrJg1.Size = new System.Drawing.Size(120, 20);
            this.lblVlrJg1.TabIndex = 8;
            this.lblVlrJg1.Text = "Valor do Jogo 1";
            this.lblVlrJg1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblVlrJogo2
            // 
            this.lblVlrJogo2.AutoSize = true;
            this.lblVlrJogo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVlrJogo2.ForeColor = System.Drawing.Color.White;
            this.lblVlrJogo2.Location = new System.Drawing.Point(261, 228);
            this.lblVlrJogo2.Name = "lblVlrJogo2";
            this.lblVlrJogo2.Size = new System.Drawing.Size(120, 20);
            this.lblVlrJogo2.TabIndex = 9;
            this.lblVlrJogo2.Text = "Valor do Jogo 2";
            // 
            // lblVlrJogo3
            // 
            this.lblVlrJogo3.AutoSize = true;
            this.lblVlrJogo3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVlrJogo3.ForeColor = System.Drawing.Color.White;
            this.lblVlrJogo3.Location = new System.Drawing.Point(261, 307);
            this.lblVlrJogo3.Name = "lblVlrJogo3";
            this.lblVlrJogo3.Size = new System.Drawing.Size(120, 20);
            this.lblVlrJogo3.TabIndex = 10;
            this.lblVlrJogo3.Text = "Valor do Jogo 3";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(399, 159);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(69, 20);
            this.textBox1.TabIndex = 11;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(399, 230);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(69, 20);
            this.textBox2.TabIndex = 12;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(399, 307);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(69, 20);
            this.textBox3.TabIndex = 13;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(125)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.lblVlr4parc);
            this.panel1.Controls.Add(this.lblVlr3parc);
            this.panel1.Controls.Add(this.lblVlr2parc);
            this.panel1.Controls.Add(this.lblVlr1parc);
            this.panel1.Controls.Add(this.lbl4parc);
            this.panel1.Controls.Add(this.lbl3parc);
            this.panel1.Controls.Add(this.lbl2parc);
            this.panel1.Controls.Add(this.lbl1parc);
            this.panel1.Location = new System.Drawing.Point(505, 100);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(251, 285);
            this.panel1.TabIndex = 14;
            // 
            // lbl1parc
            // 
            this.lbl1parc.AutoSize = true;
            this.lbl1parc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1parc.Location = new System.Drawing.Point(49, 59);
            this.lbl1parc.Name = "lbl1parc";
            this.lbl1parc.Size = new System.Drawing.Size(91, 20);
            this.lbl1parc.TabIndex = 0;
            this.lbl1parc.Text = "1 pacela de";
            this.lbl1parc.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // lbl2parc
            // 
            this.lbl2parc.AutoSize = true;
            this.lbl2parc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2parc.Location = new System.Drawing.Point(49, 110);
            this.lbl2parc.Name = "lbl2parc";
            this.lbl2parc.Size = new System.Drawing.Size(91, 20);
            this.lbl2parc.TabIndex = 1;
            this.lbl2parc.Text = "2 pacela de";
            // 
            // lbl3parc
            // 
            this.lbl3parc.AutoSize = true;
            this.lbl3parc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3parc.Location = new System.Drawing.Point(49, 156);
            this.lbl3parc.Name = "lbl3parc";
            this.lbl3parc.Size = new System.Drawing.Size(91, 20);
            this.lbl3parc.TabIndex = 2;
            this.lbl3parc.Text = "3 pacela de";
            // 
            // lbl4parc
            // 
            this.lbl4parc.AutoSize = true;
            this.lbl4parc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl4parc.Location = new System.Drawing.Point(49, 203);
            this.lbl4parc.Name = "lbl4parc";
            this.lbl4parc.Size = new System.Drawing.Size(91, 20);
            this.lbl4parc.TabIndex = 3;
            this.lbl4parc.Text = "4 pacela de";
            // 
            // lblVlr1parc
            // 
            this.lblVlr1parc.AutoSize = true;
            this.lblVlr1parc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVlr1parc.Location = new System.Drawing.Point(184, 59);
            this.lblVlr1parc.Name = "lblVlr1parc";
            this.lblVlr1parc.Size = new System.Drawing.Size(14, 20);
            this.lblVlr1parc.TabIndex = 4;
            this.lblVlr1parc.Text = "-";
            this.lblVlr1parc.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // lblVlr2parc
            // 
            this.lblVlr2parc.AutoSize = true;
            this.lblVlr2parc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVlr2parc.Location = new System.Drawing.Point(184, 110);
            this.lblVlr2parc.Name = "lblVlr2parc";
            this.lblVlr2parc.Size = new System.Drawing.Size(14, 20);
            this.lblVlr2parc.TabIndex = 5;
            this.lblVlr2parc.Text = "-";
            // 
            // lblVlr3parc
            // 
            this.lblVlr3parc.AutoSize = true;
            this.lblVlr3parc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVlr3parc.Location = new System.Drawing.Point(184, 156);
            this.lblVlr3parc.Name = "lblVlr3parc";
            this.lblVlr3parc.Size = new System.Drawing.Size(14, 20);
            this.lblVlr3parc.TabIndex = 6;
            this.lblVlr3parc.Text = "-";
            // 
            // lblVlr4parc
            // 
            this.lblVlr4parc.AutoSize = true;
            this.lblVlr4parc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVlr4parc.Location = new System.Drawing.Point(184, 207);
            this.lblVlr4parc.Name = "lblVlr4parc";
            this.lblVlr4parc.Size = new System.Drawing.Size(14, 20);
            this.lblVlr4parc.TabIndex = 7;
            this.lblVlr4parc.Text = "-";
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(80, 376);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(346, 53);
            this.btnCalc.TabIndex = 15;
            this.btnCalc.Text = "CALCULAR";
            this.btnCalc.UseVisualStyleBackColor = true;
            // 
            // FrmGames
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(87)))), ((int)(((byte)(16)))), ((int)(((byte)(137)))));
            this.ClientSize = new System.Drawing.Size(753, 449);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblVlrJogo3);
            this.Controls.Add(this.lblVlrJogo2);
            this.Controls.Add(this.lblVlrJg1);
            this.Controls.Add(this.txtJogo3);
            this.Controls.Add(this.txtJogo2);
            this.Controls.Add(this.txtJogo1);
            this.Controls.Add(this.lblJogo3);
            this.Controls.Add(this.lblJogo2);
            this.Controls.Add(this.lblJogo1);
            this.Controls.Add(this.panel3);
            this.Name = "FrmGames";
            this.Text = "Form1";
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblJogo1;
        private System.Windows.Forms.Label lblJogo2;
        private System.Windows.Forms.Label lblJogo3;
        private System.Windows.Forms.TextBox txtJogo1;
        private System.Windows.Forms.TextBox txtJogo2;
        private System.Windows.Forms.TextBox txtJogo3;
        private System.Windows.Forms.Label lblVlrJg1;
        private System.Windows.Forms.Label lblVlrJogo2;
        private System.Windows.Forms.Label lblVlrJogo3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl1parc;
        private System.Windows.Forms.Label lblVlr1parc;
        private System.Windows.Forms.Label lbl4parc;
        private System.Windows.Forms.Label lbl3parc;
        private System.Windows.Forms.Label lbl2parc;
        private System.Windows.Forms.Label lblVlr4parc;
        private System.Windows.Forms.Label lblVlr3parc;
        private System.Windows.Forms.Label lblVlr2parc;
        private System.Windows.Forms.Button btnCalc;
    }
}

