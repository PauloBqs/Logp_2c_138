﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NumeroElevado
{
    public partial class Fmrtela1 : Form
    {
        public Fmrtela1()
        {
            InitializeComponent();
        }

        private void txtNumero_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnResultado_Click(object sender, EventArgs e)
        {
            float numero = float.Parse(txtNumero.Text);
            float resultado;

            resultado = Math.Pow(numero,5);

            MessageBox.Show("O resultado é igual a " + resultado);
        }
    }
}
