﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapturandoDados
{
    public partial class FrmDados : Form
    {
        public FrmDados()
        {
            InitializeComponent();
        }

   

        private void FrmDados_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Iniciou o Formulario");
        }

        private void lblInteiro_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicou na label Inteiro");
        }

     

        

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicou em enviar");
        }

        private void txtInteiro_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Alterou o texto");
        }
    }
}
