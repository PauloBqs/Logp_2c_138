﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtN2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSubtração_Click(object sender, EventArgs e)
        {
            float varN1 = float.Parse(txtN1.Text);
            float varN2 = float.Parse(txtN2.Text);
            float resultado = varN1 - varN2;
            MessageBox.Show("O resultado da subtração é igual a " + resultado);
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            float varN1 = float.Parse(txtN1.Text);
            float varN2 = float.Parse(txtN2.Text);
            float resultado = varN1 + varN2;
            MessageBox.Show("O resultado da soma é igual a " + resultado);

            
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            float varN1 = float.Parse(txtN1.Text);
            float varN2 = float.Parse(txtN2.Text);
            float resultado = varN1 * varN2;
            MessageBox.Show("O resultado da multiplicação é igual a " + resultado);
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            float varN1 = float.Parse(txtN1.Text);
            float varN2 = float.Parse(txtN2.Text);
            float resultado = varN1 / varN2;
            MessageBox.Show("O resultado da divisão é igual a " + resultado);
        }

        
    }
}
