﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Logica
{
    public partial class FormExercicio : Form
    {
        public FormExercicio()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            float n1 = float.Parse(txtN1.Text);
            float n3 = float.Parse(txtN3.Text);

            float soma;

            soma = n1 + n3;
            MessageBox.Show("Resultado da soma da primeiro e ultimo numero é " + soma);

        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            float n1 = float.Parse(txtN1.Text);
            float n2 = float.Parse(txtN2.Text);
            float n3 = float.Parse(txtN3.Text);
            float media;
            media = (n1 + n2 + n3) / 3;
            MessageBox.Show("A media é igual a " + media);
        }

        private void btnPocentagem_Click(object sender, EventArgs e)
        {
            float n1 = float.Parse(txtN1.Text);
            float n2 = float.Parse(txtN2.Text);
            float n3 = float.Parse(txtN3.Text);

            float porcentagem1;
            porcentagem1 = n1 / (n1 + n2 + n3) * 100;
            MessageBox.Show("A porcentagem do primeiro numero é " + porcentagem1 + "%");


        }

        private void txtN1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
