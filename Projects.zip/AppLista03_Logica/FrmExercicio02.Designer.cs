﻿namespace AppLista03_Logica
{
    partial class FrmExercicio02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPago = new System.Windows.Forms.Label();
            this.lblGasolina = new System.Windows.Forms.Label();
            this.txtPago = new System.Windows.Forms.TextBox();
            this.txtGasolina = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPago
            // 
            this.lblPago.AutoSize = true;
            this.lblPago.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPago.Location = new System.Drawing.Point(97, 85);
            this.lblPago.Name = "lblPago";
            this.lblPago.Size = new System.Drawing.Size(118, 25);
            this.lblPago.TabIndex = 0;
            this.lblPago.Text = "Valor Pago";
            // 
            // lblGasolina
            // 
            this.lblGasolina.AutoSize = true;
            this.lblGasolina.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGasolina.Location = new System.Drawing.Point(97, 179);
            this.lblGasolina.Name = "lblGasolina";
            this.lblGasolina.Size = new System.Drawing.Size(189, 25);
            this.lblGasolina.TabIndex = 1;
            this.lblGasolina.Text = "Preço da Gasolina";
            // 
            // txtPago
            // 
            this.txtPago.Location = new System.Drawing.Point(102, 130);
            this.txtPago.Name = "txtPago";
            this.txtPago.Size = new System.Drawing.Size(130, 20);
            this.txtPago.TabIndex = 2;
            this.txtPago.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtGasolina
            // 
            this.txtGasolina.Location = new System.Drawing.Point(104, 228);
            this.txtGasolina.Name = "txtGasolina";
            this.txtGasolina.Size = new System.Drawing.Size(128, 20);
            this.txtGasolina.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(104, 299);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(128, 46);
            this.button1.TabIndex = 4;
            this.button1.Text = "Ver litros enchidos";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FrmExercicio02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtGasolina);
            this.Controls.Add(this.txtPago);
            this.Controls.Add(this.lblGasolina);
            this.Controls.Add(this.lblPago);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Name = "FrmExercicio02";
            this.Text = "FrmExercicio02";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPago;
        private System.Windows.Forms.Label lblGasolina;
        private System.Windows.Forms.TextBox txtPago;
        private System.Windows.Forms.TextBox txtGasolina;
        private System.Windows.Forms.Button button1;
    }
}